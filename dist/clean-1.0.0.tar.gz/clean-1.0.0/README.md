Description:
The script is designed to sort files, depending on their extension, into folders.

Install:
Go to the folder with the script;
At the command line, enter the command 'pip install -e .' (you may need to run the command line with administrator privileges);
Wait until the installation is completed.

Usage:
After script installation, in the command line enter the command 'clean' and type the path to folder, which you want to clean, then press Enter;
After entering the 'clean' command, to run the script, press Enter;
When the script finishes, the command line will display the message 'Everything is cleaned!'.